---
n: 18
fase: 3
titulo: O critério como conteúdo
subtitulo: Mostrar como você decide vale mais do que mostrar o que você sabe
epigrafe: Informação qualquer um copia. A régua com que você decide, não.
ilustracao: mapa
legenda_ilustracao: O mapa é o mesmo para todos. O que muda é o caminho que cada um escolhe.
---

A proposta chegou por mensagem, numa sexta-feira à tarde, e parecia boa demais. Um investidor tinha comprado três apartamentos num prédio de 1965 no Centro de Campinas, perto da rodoviária, e queria reformar os três para aluguel de temporada. Prazo de quarenta dias, orçamento enxuto, pagamento em dia. Era o maior trabalho que tinha aparecido para o escritório naquele ano. Caio marcou a visita para a segunda-feira.

Nos três apartamentos, encontrou o que esperava de um prédio daquela idade. Uma infiltração antiga no banheiro do terceiro andar, que já tinha manchado a parede da sala. Fiação de pano em parte dos cômodos, escondida atrás de tomadas novas que alguém tinha trocado sem mexer no que havia dentro. Um quadro de luz que esquentava quando se ligava o chuveiro e a máquina de lavar ao mesmo tempo. Os canos de ferro do banheiro, com a água saindo amarelada no primeiro minuto. Nada que não tivesse solução. Tudo que custava mais tempo e mais dinheiro do que o investidor tinha previsto.

O investidor ouviu a lista com paciência. Aceitou trocar o quadro e a fiação sem discutir: isso era segurança, e ali não havia régua, havia norma. O resto ele queria resolver com uma lógica que tinha a sua coerência. Ninguém ia morar ali mais do que três ou quatro dias. Bastava pintar a parede manchada, deixar os canos de ferro do banheiro como estavam e colocar um piso vinílico por cima do taco solto. O hóspede não ia abrir a parede.

Caio respondeu com uma obra, como responde quase tudo. Teve uma obra em que o hóspede também não ia abrir a parede, e a infiltração abriu sozinha, no segundo verão, em cima da cama de casal. O investidor riu e disse que, se um dia desse problema, ele resolvia.

Na volta para o escritório, Caio fez as contas no carro, parado num sinal da Avenida Andrade Neves. Os três apartamentos pagariam o aluguel da sala até o fim do ano e o salário do estagiário por mais seis meses. O sócio, quando soube, disse que talvez desse para fazer do jeito do cliente e deixar tudo registrado em ata. Caio passou o fim de semana pensando nisso. Na segunda, a ata lhe pareceu uma forma de dividir a culpa por um problema que ele tinha visto e deixado fechado.

Recusou o projeto no mesmo dia, por escrito, em três parágrafos: não fechava parede sobre um problema que tinha visto sem que quem viesse depois soubesse dele, e oferecia uma proposta com o prazo e o orçamento que o prédio pedia. O investidor agradeceu e contratou outro escritório.

Naquela noite, Caio abriu o caderno de campo e percebeu que não era a primeira vez. Nos oito anos de escritório, tinha recusado outras propostas parecidas, sempre com a mesma frase na cabeça, sem nunca escrevê-la. Escreveu, e depois as três perguntas que fazia a si mesmo, em silêncio, antes de aceitar qualquer obra. Dez dias depois, passando pela rodoviária, viu uma caçamba de entulho na porta do prédio.

## O que o cliente consegue julgar

Há uma coisa que o cliente de um arquiteto não consegue fazer: avaliar se o arquiteto é tecnicamente bom. Ele não tem repertório para isso. Não sabe se a laje aguenta, se o traço da argamassa está certo, se existia uma solução melhor para a cozinha. Está comprando um serviço que não sabe julgar.

O que ele consegue avaliar muito bem é o raciocínio. Quando Caio explica por que recusa obras que escondem problemas, quem ouve não precisa entender de impermeabilização para perceber que a decisão foi pensada. Reconhece o bom raciocínio quando o vê, e reconhece também a falta dele. É por isso que mostrar como você decide costuma convencer mais do que mostrar o que você sabe.

Pense no que um cliente conta a um amigo depois de uma boa consulta. Não repete a técnica; não saberia. Conta a decisão: "ele me explicou por que não ia operar ainda", "ela me disse que o processo não valia o desgaste". Publicar a régua é pôr por escrito, antes da primeira conversa, aquilo que o cliente satisfeito contaria depois.

```conceito
termo: Critério
definicao: A régua que você usa para escolher entre duas opções defensáveis: a sua, a de quem decide, o seu, o de quem decide, e não o que a peça devolve a quem lê (capítulos 13 e 15). É a camada mais funda do repertório, a que o capítulo 9 pôs na base: dois profissionais com a mesma informação decidem diferente porque têm critérios diferentes.
porque: O cliente não consegue avaliar a sua técnica, mas consegue avaliar o seu raciocínio. O critério é a prova de competência que um leigo sabe ler.
```

O critério também é o que menos se copia. A informação técnica de qualquer área está em livros e cursos, e um concorrente atento pode reproduzi-la. A régua com que você escolhe entre dois caminhos foi formada pelos seus casos, pelos seus erros e pelo seu jeito de pesar riscos. Alguém pode repetir a frase do Caio sobre obras que escondem problemas. Não consegue repetir os oito anos de visitas em que ele aprendeu onde os problemas se escondem.

## Onde o critério aparece

Só existe critério onde há escolha. Se o seu trabalho tem um único caminho possível num determinado ponto, ali há protocolo, e protocolo não é régua. Procure na sua prática as bifurcações: os momentos em que duas saídas são defensáveis e você escolhe uma delas por um motivo que é seu.

As três perguntas que Caio escreveu no caderno naquela noite servem de mapa para essa procura. O que este prédio esconde? Quem vai usar este espaço depois do cliente que me contratou? O que vai ficar por fazer, e quem vai saber disso? Cada pergunta marca um ponto em que ele viu colegas seguirem por outro lado. Na sua área, as perguntas serão outras, mas a pista é a mesma: os pontos em que você decide diferente de alguém que respeita são os pontos em que há critério.

Tabela: Quatro tipos de critério que se podem publicar

| Tipo | A pergunta que ele responde | Por que convence |
|---|---|---|
| De entrada | Quando você aceita e quando recusa um trabalho | A recusa é a prova de critério mais forte que existe |
| De escolha | Como você decide entre A e B, quando os dois servem | Mostra como você pensa |
| De parada | Quando você decide que já basta | Contraria o próprio interesse, e por isso é crível |
| De encaminhamento | Quando o caso não é seu e vai para outro | Prova honestidade no ato |

Os quatro personagens têm critérios dos quatro tipos, sem chamá-los assim. O de Caio, nesta semana, é de entrada. Otávio decide pela prova, e a régua dele é de escolha: quando o horário de trabalho está documentado, ele defende até a sentença; quando a empresa era obrigada a ter o ponto e não tem, propõe acordo na primeira audiência, mesmo que o dono queira brigar, porque começa pela pior hipótese. O de Renata é de encaminhamento: quando a dor contraria o laudo, ela manda o paciente de volta ao médico antes de começar, mesmo que isso lhe custe o paciente; com o ex-motorista do capítulo 9, um detalhe do supermercado valeu mais que o laudo de hérnia. O de Lúcia é de parada: ela propõe encerrar a terapia quando percebe que o paciente já consegue fazer sozinho o que vinha fazer ali, mesmo quando ele gostaria de continuar.

Quase ninguém publica a régua de parada. Dizer "aqui eu paro" parece deixar dinheiro na mesa, e é justamente essa aparência que o torna crível. Quem lê entende que aquele profissional coloca alguma coisa acima do próprio faturamento.

Lúcia demorou a dizer a sua régua em voz alta. Tinha medo de que um paciente novo ouvisse "eu proponho encerrar" como "eu vou mandar você embora". Na peça que acabou gravando, com a amiga do grupo de estudos fazendo as perguntas, ela explicou o sinal que observa: o paciente chega à sessão contando como resolveu sozinho uma situação que antes o trazia ali. Disse também que propor o fim é abrir uma conversa sobre ele, que pode durar semanas.

## Como tornar o critério legível

Um critério publicado tem quatro partes. A primeira é a bifurcação: dizer que, naquele ponto, existem dois caminhos, e que os dois são defensáveis. Sem isso, o leitor pensa que você está descrevendo o óbvio. A segunda é o custo de cada caminho, mais do que o benefício. Todo caminho oferece alguma coisa; o que informa é saber o que cada um cobra, em tempo, em dinheiro, em risco ou em possibilidade de voltar atrás.

A terceira parte é a régua propriamente dita, escrita como uma condição que se pode verificar: "eu escolho A quando acontece tal coisa". Preferências vagas, como "depende de cada caso" ou "avalio individualmente", não são régua; são a ausência dela dita com educação. A quarta parte é a mais difícil: dizer onde a sua régua já errou. Um critério cujo limite você conhece é um critério que foi usado de verdade. Um critério sem limite conhecido provavelmente nunca foi testado.

Caio escreveu as quatro partes no caderno. A bifurcação: numa reforma de prédio antigo com prazo curto, depois de resolvido o que é segurança, há quem feche o que viu e deixe o aviso por conta do dono, e há quem abra antes de fechar. Os dois caminhos são defensáveis; num imóvel de temporada, adiar a infiltração e os canos pode levar anos para cobrar, e o dono assume esse risco. Caio conhece colegas bons que fazem o primeiro. O custo do primeiro é o problema que volta, no pior momento e para alguém que não sabia dele. O custo do segundo é o prazo e o orçamento, que nas obras dele crescem e às vezes fazem o cliente desistir.

A régua dele cabia numa frase: se ninguém que vai usar o espaço depois vai saber do problema que eu vi, eu abro antes de fechar, ou não faço a obra. E, ao escrever, entendeu de onde vinha a terceira pergunta. Três anos antes, Caio tinha recusado uma obra rápida de uma senhora que precisava vender o apartamento às pressas por um motivo de família. Aplicou a régua sem perguntar quem ia saber. Semanas depois, pelo corretor, soube que ela pretendia informar o comprador de tudo, e que só precisava do imóvel apresentável. Desde então, antes de recusar, pergunta quem vai saber do que ficou por fazer.

```exemplo
titulo: Conhecimento e critério sobre o mesmo assunto
comum: Um ortopedista, sobre lesão de menisco. "Existem duas abordagens principais para esse tipo de lesão, a conservadora e a cirúrgica. Cada uma tem as suas indicações, e cabe ao médico avaliar qual é a mais adequada para cada paciente."
singular: O mesmo ortopedista, mostrando a régua. "Aqui existem duas saídas, e as duas são defensáveis. A fisioterapia custa tempo: você convive com o incômodo por mais alguns meses. A cirurgia custa o que não se desfaz. Quando a lesão é de desgaste e a pessoa tem mais de quarenta anos, eu começo pela fisioterapia, mesmo que ela me peça a cirurgia. Essa régua já me fez esperar demais em joelhos que travavam; hoje, se o joelho trava, eu não espero."
porque: A primeira versão mostra conhecimento e não decide nada; devolve a decisão ao médico sem explicar como ele decide. A segunda mostra os custos, a régua e o limite dela. Um leigo consegue julgar a qualidade desse raciocínio sem entender a técnica.
```

## O efeito de um critério público

Publicado o critério, parte de quem lê se reconhece e passa a preferir você. Outra parte percebe que não concorda com a sua régua e decide procurar outro profissional. As duas reações são boas. A segunda parece perda, mas muitas vezes são os clientes que dariam problema depois, quando a régua fosse aplicada a eles.

```figura
tipo: funil
titulo: O que acontece quando o critério é público
etapas:
  - {rotulo: "A pessoa lê o seu critério", nota: "Sem conhecer você, sem indicação."}
  - {rotulo: "Reconhece um bom raciocínio", nota: "Avalia o raciocínio."}
  - {rotulo: "Reconhece-se ou se afasta", nota: "Os dois resultados são bons: o filtro acontece antes da primeira conversa."}
  - {rotulo: "Chega concordando com a régua", nota: "A objeção já foi respondida."}
  - {rotulo: "Aceita a condução do trabalho", nota: "Escolheu você pela régua."}
```

O investidor dos três apartamentos, se tivesse lido a régua do Caio antes de mandar a mensagem, provavelmente teria procurado outro escritório desde o começo, e os dois teriam poupado uma visita e uma semana de conversa. Quem chega concordando com a régua já sabe, antes da primeira reunião, por que o prazo é maior.

A régua se publica sem quem a motivou. Caio não contou a história do investidor, nem o endereço do prédio, nem o número de apartamentos. O investidor não se reconheceria na peça; quem estivesse pensando em fazer o mesmo, sim.

A régua também não se publica como acusação. O escritório que aceitou os três apartamentos deve ter trocado o quadro e a fiação, que o investidor já tinha aceitado, e escolheu o outro caminho para o resto; talvez tenha uma régua diferente, talvez tenha encontrado uma solução que Caio não viu. Um critério publicado diz o que você faz e por quê. Quando passa a dizer o que os outros fazem de errado, vira ataque, e deixa de ser critério.

Numa quinta de maio, antes de ter decidido qualquer formato, Caio contou em voz alta ao sócio uma obra antiga, anotou o que tinha dito e publicou como um texto curto. Começou por uma obra em que tinha aberto uma parede para trocar um cano que ninguém veria, disse os dois caminhos e a régua, e terminou no limite dela, contado sem a senhora: uma vez recusou uma obra sem perguntar quem ia saber do que ficava por fazer.

Na semana seguinte, foi ver com um casal, indicado por um cliente antigo, um apartamento de 1958 no Bosque. O marido perguntou o que Caio abriria primeiro. Ele apontou a parede da cozinha, onde a tinta descascava num desenho que conhecia bem, e disse que não sabia o que havia atrás dela. Explicou que só fecharia o orçamento depois de abrir. O marido quis saber quanto tempo levava abrir, e se dava para morar lá enquanto isso. Caio respondeu com a obra de sempre, a do cano que ninguém veria.

```guardar
- O cliente não consegue avaliar a sua técnica, mas consegue avaliar o seu raciocínio. O critério é a prova de competência que um leigo sabe ler.
- "Um critério publicável tem quatro partes: a bifurcação, o custo de cada caminho, a régua verificável e o limite que ela já mostrou."
- Quem discorda da sua régua deixa de procurar você. Parece perda; muitas vezes são os casos que dariam problema depois.
```

```oficina
titulo: A sua régua, publicada
objetivo: Tornar visível um critério da sua prática, o raciocínio que o cliente consegue julgar e que nenhum concorrente consegue copiar.
tempo: 30
entrega: Um critério nas quatro partes, com o tipo identificado e o limite admitido.
campos:
  - rotulo: "Que tipo de critério você vai escrever?"
    grade:
      colunas: ["Este"]
      linhas: ["De entrada: quando aceito ou recuso", "De escolha: entre A e B", "De parada: quando já basta", "De encaminhamento: quando não é comigo"]
  - rotulo: "A situação e as duas saídas, as duas defensáveis"
    exemplo: "Se uma delas é claramente pior, não é bifurcação. Procure outra. Uma veterinária: “Para cão idoso com tártaro e sopro leve, há a limpeza com anestesia agora e o controle em casa por mais seis meses.”"
    linhas: 3
  - rotulo: "O que cada caminho custa"
    exemplo: "Tempo, dinheiro, risco, possibilidade de voltar atrás. A veterinária: “A limpeza agora custa o risco da anestesia; esperar custa dor e dente perdido.”"
    linhas: 4
  - rotulo: "A sua régua: eu escolho ___ quando ___"
    exemplo: "Uma condição que dá para verificar. “Depende do caso” não é régua. A veterinária: “Eu indico a anestesia quando os exames de sangue e do coração estão dentro do esperado para a idade.”"
    linhas: 2
  - rotulo: "Onde essa régua já falhou, e o que você ajustou"
    exemplo: "A veterinária: “Errei com um cão cujo sopro piorou entre o exame e a data marcada. Hoje refaço a avaliação do coração se passar de um mês.”"
    linhas: 3
criterios:
  - As duas saídas do campo 02 são defensáveis de verdade.
  - A régua do campo 04 tem uma condição verificável.
  - O limite do campo 05 aconteceu de fato.
```

```rede
titulo: Como eu decido
intro: "Publique a régua da oficina. O assunto é uma decisão típica da sua área; nenhum cliente, recusado ou atendido, pode ser reconhecido nela."
regras:
  - {regra: "Diga que há dois caminhos defensáveis.", porque: "Sem a bifurcação, quem lê acha que você está descrevendo o óbvio, e o critério desaparece."}
  - {regra: "Fale do custo de cada caminho.", porque: "Todo caminho oferece alguma coisa. O que ajuda alguém a decidir é saber o que cada um cobra."}
  - {regra: "Diga o que a sua régua faz você deixar de fazer.", porque: "Toda régua tem um lado que você recusa, mesmo quando pagaria bem: o trabalho que não aceita, o caminho que não escolhe, o atendimento que não prolonga, o caso que manda para outro. É a parte mais fácil de ler."}
faca:
  - "“Quando o cliente chega com tal quadro, há dois caminhos, e os dois são defensáveis.”"
  - "“Eu escolho este quando acontece tal coisa.”"
  - "“Essa régua já me fez errar uma vez; desde então, eu pergunto…”"
evite:
  - "“Depende de cada caso” como resposta final."
  - Contar o caso do cliente que motivou a régua.
  - Apresentar o caminho que você não escolhe como erro de quem o escolhe.
esqueleto_rotulo: "Passe a limpo os campos 02 a 05, em frases de quem lê"
esqueleto:
  - {rotulo: "A bifurcação", texto: "A situação e os dois caminhos, ditos com justiça.", linhas: 2}
  - {rotulo: "Os custos", texto: "O que cada caminho cobra.", linhas: 2}
  - {rotulo: "A régua", texto: "Eu escolho este quando…", linhas: 2}
  - {rotulo: "O limite", texto: "Onde a régua já falhou, e o que mudou.", linhas: 2}
roteiro: |
  Quando {a situação típica da sua área}, existem dois caminhos, e os dois são defensáveis: {caminho A} e {caminho B}.

  O primeiro custa {o custo de A}. O segundo custa {o custo de B}.

  A minha régua é esta: eu escolho {o seu caminho} quando {a condição verificável}.

  Ela já me fez errar uma vez, quando {o limite}. Desde então, {o ajuste}.
roteiro_nota: Uma régua por peça. Em saúde, psicologia e direito, diga que ela mostra como você decide, e que não substitui a avaliação de quem lê por um profissional.
```

```verificacao
- pergunta: Por que mostrar o critério costuma convencer mais do que mostrar conhecimento?
  opcoes:
    - Porque o critério é mais curto de explicar numa peça.
    - Porque o leigo não julga a técnica, mas julga o raciocínio.
    - Porque o critério dispensa conhecimento técnico de quem publica.
    - Porque o critério costuma gerar mais comentários.
  correta: 1
  explicacao: O cliente compra um serviço que não sabe avaliar tecnicamente. O raciocínio, porém, é legível para qualquer pessoa, e a falta dele também.
- pergunta: Onde existe critério, no sentido deste capítulo?
  opcoes:
    - Em qualquer etapa técnica do trabalho.
    - Nas etapas mais complexas e caras do serviço.
    - Onde há dois caminhos defensáveis e você escolhe um.
    - Nos casos que envolvem mais dinheiro.
  correta: 2
  explicacao: Onde há um único caminho, há protocolo. O critério aparece na bifurcação, quando os dois caminhos servem e a escolha depende da sua régua.
- pergunta: Por que o critério de parada é o mais raro e o mais crível?
  opcoes:
    - Porque contraria o próprio interesse de quem o aplica.
    - Porque é o mais fácil de explicar a quem não é da área.
    - Porque encurta o tempo de cada atendimento.
    - Porque exige um conselho profissional que o autorize.
  correta: 0
  explicacao: Dizer “aqui eu paro” parece deixar dinheiro na mesa, e é essa aparência que o torna crível. Lúcia, ao propor o fim da terapia, é o exemplo do livro.
- pergunta: Por que Caio passou a perguntar, antes de recusar, quem vai saber do que ficou por fazer?
  opcoes:
    - Porque o escritório precisava aceitar mais projetos naquele ano.
    - Porque o investidor dos três apartamentos voltou a procurá-lo.
    - Porque a norma de reformas passou a exigir essa pergunta.
    - Porque a régua já tinha errado com uma cliente que ia avisar o comprador.
  correta: 3
  explicacao: A senhora que vendia o apartamento às pressas ia informar o comprador de tudo. O erro mostrou o limite da régua, e o ajuste a tornou mais precisa.
```

```aplicacao
itens:
  - {rotulo: "Encontrei uma bifurcação real", ajuda: "Dois caminhos defensáveis, com o tipo marcado (campos 01 e 02).", pontos: 3}
  - {rotulo: "Escrevi o custo de cada caminho", ajuda: "O que cada um cobra (campo 03).", pontos: 2}
  - {rotulo: "Escrevi a régua de forma verificável", ajuda: "Eu escolho ___ quando ___ (campo 04).", pontos: 3}
  - {rotulo: "Admiti um limite real", ajuda: "Onde a régua falhou e o que mudou (campo 05).", pontos: 2}
```
